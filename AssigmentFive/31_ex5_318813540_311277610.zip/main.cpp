#include "Simulator.h"

int main(int argc,char **argv) {
  Simulator sim(argc,argv);
  sim.go();
  return 0;
}
